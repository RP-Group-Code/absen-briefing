<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PegawaiController extends Controller
{
    public function index()
    {
        DB::statement("SET SESSION sql_mode=''");

        $data['pegawai'] = Pegawai::select('pegawais.*')
            ->leftJoin('absens', function ($join) {
                $join->on('absens.pegawai_id', '=', 'pegawais.id')
                    ->whereMonth('absens.created_at', date('m'));
            })
            ->leftJoin('ukers', 'ukers.id', '=', 'pegawais.uker_id')
            ->addSelect(DB::raw('COUNT(absens.id) as jumlah_absen'))
            ->groupBy('pegawais.id')
            ->orderByRaw('COUNT(absens.id) DESC, ukers.nama ASC') // ← ganti ini
            ->get();
        return view('pegawai.index', $data);
    }
}
