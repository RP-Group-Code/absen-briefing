@extends('layouts.app')

@section('title', 'Master Pegawai')

@section('content')
    <div class="container-fluid px-3 px-md-4 py-4">

        <div class="stats-wrapper mb-4">
            <p class="section-title">
                <i class="fa-solid fa-users fa-sm"></i>
                Pegawai Overview
            </p>

            <div class="table-responsive">
                <table class="myTable table table-hover mb-0 display ">
                    <thead class="table-light">
                        <tr>
                            <th width="50">#</th>
                            <th>Uker</th>
                            <th>PN</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Jumlah Absen {{ date('M-Y') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($pegawai as $index => $data)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>( {{ $data->uker->kode_uker }} ) - {{ $data->uker->nama }} </td>
                                <td>{{ $data->pn }}</td>
                                <td>{{ $data->nama }}</td>
                                <td>{{ $data->jabatan }}</td>
                                <td>{{ $data->jumlah_absen }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
