@extends('layouts.app-public')

@section('title', 'Absen Briefing Kanca')

@section('content')
    @php
        $selectedId = $selectedRow['id'] ?? null;
        $selectedName = $selectedRow['name'] ?? '(Belum memilih pegawai)';
        $selectedNotes = $selectedRow['notes'] ?? '';
        $selectedStatus = $selectedRow['status'] ?? 'Masuk';
    @endphp

    <div class="px-5 py-2">
        <div class="header-card kanca-header">
            <div class="header-brand">
                <div class="header-icon">
                    <i class="fa-solid fa-users-viewfinder"></i>
                </div>
                <div>
                    <div class="header-title">Absen Briefing Kanca</div>
                    <div class="header-sub">BO Palembang Sriwijaya</div>
                </div>
            </div>

            <div class="row">
                <div class="col-3">
                    <div class="header-pills">
                        <span class="info-pill"><i class="fa-solid fa-users"></i> Total: <strong
                                id="totalEmployeesText">{{ $totalEmployees }}</strong></span>
                        <span class="info-pill"><i class="fa-solid fa-building"></i> Scope:
                            <strong
                                id="scopeText">{{ $activeDivision !== '' ? $activeDivision : 'Semua Divisi' }}</strong></span>
                    </div>
                </div>
                <div class="col-9">
                    <div class="header-notice">
                        <i class="fa-solid fa-circle-info mt-1 flex-shrink-0"></i>
                        <span>Klik salah satu baris pegawai untuk ubah status pada tanggal aktif. - Jangan lupa untuk menyimpan status briefing pegawai !!!</span>
                    </div>
                </div>
            </div>



        </div>

        <div class="glass-card toolbar-card">
            <form method="GET" action="{{ route('Input-Index-Kanca') }}" id="filterForm" class="toolbar-form">
                <input type="hidden" name="selected" id="selected_filter" value="{{ $selectedId }}">

                <div class="control-group control-date">
                    <label for="date" class="mini-label">Tanggal</label>
                    <input type="date" id="date" name="date" value="{{ $activeDate }}" class="ctl ctl-input">
                </div>

                <div class="control-group control-nav">
                    <label class="mini-label">Navigasi Divisi</label>
                    <div class="nav-wrap">
                        <button type="button" class="ctl ctl-nav" id="divisionPrevBtn" title="Divisi Sebelumnya">
                            <i class="fa-solid fa-chevron-left"></i>
                        </button>
                        <button type="button" class="ctl ctl-nav" id="divisionNextBtn" title="Divisi Berikutnya">
                            <i class="fa-solid fa-chevron-right"></i>
                        </button>
                    </div>
                </div>

                <div class="control-group control-division">
                    <label for="division" class="mini-label">Divisi</label>
                    <select id="division" name="division" class="ctl ctl-input">
                        <option value="">Semua Divisi</option>
                        @foreach ($divisions as $division)
                            <option value="{{ $division }}" @selected($activeDivision === $division)>
                                {{ $division }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="control-group control-search">
                    <label for="search" class="mini-label">Search</label>
                    <div class="search-wrap">
                        <input type="text" id="search" name="search" value="{{ $search }}"
                            placeholder="Nama / Jabatan / Divisi" class="ctl ctl-input">
                        <a href="{{ route('absen.kanca.export', ['date' => $activeDate, 'division' => $activeDivision, 'search' => $search]) }}"
                            id="exportExcelBtn" class="btn-standard btn-export">
                            <i class="fa-solid fa-file-excel"></i>
                            <span>Export Excel</span>
                        </a>
                    </div>
                </div>

                {{-- <div class="control-group control-submit">
                    <label class="mini-label">Aksi</label>
                    <button type="submit" class="btn-standard">Apply Filter</button>
                </div> --}}
            </form>
        </div>

        <div class="kanca-grid">
            <div class="glass-card table-card">
                <div class="table-headline">
                    <span class="left"><i class="fa-solid fa-table-list"></i> Daftar Pegawai</span>
                    <span class="right" id="activeDateText">{{ date('d M Y') }}</span>
                </div>

                <div class="table-scroll">
                    <table class="kanca-table" id="attendanceTable">
                        <thead>
                            <tr>
                                <th>Divisi</th>
                                <th>Jabatan</th>
                                <th>Pekerja</th>
                                <th>Status</th>
                                <th>Indikator</th>
                            </tr>
                        </thead>
                        <tbody class="text-uppercase">
                            @forelse ($rows as $row)
                                @php
                                    $isSelected = (int) $row['id'] === (int) $selectedId;
                                @endphp
                                <tr class="employee-row {{ $isSelected ? 'selected' : '' }}"
                                    data-kanca-id="{{ $row['id'] }}" data-name="{{ $row['name'] }}"
                                    data-status="{{ $row['status'] }}" data-notes="{{ $row['notes'] }}">
                                    <td>{{ $row['division'] }}</td>
                                    <td>{{ $row['jabatan'] }}</td>
                                    <td>{{ $row['name'] }}</td>
                                    <td>
                                        <span
                                            class="status-tag status-{{ strtolower($row['status']) }}">{{ $row['status'] }}</span>
                                    </td>
                                    <td>{{ $row['indicator'] }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5" class="empty-state">Data pegawai belum tersedia. Jalankan seeder
                                        `KancaSeeder` dulu.</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>

            <aside class="kanca-side">
                <section class="glass-card side-card">
                    <div class="side-title">Ubah Status Pegawai</div>
                    <div id="selectedPegawai" class="selected-label">{{ $selectedName }}</div>

                    <div class="current-status-wrap">
                        <span class="mini-label">Status Terpilih</span>
                        <span id="selectedStatusBadge" class="status-tag status-{{ strtolower($selectedStatus) }}">
                            {{ $selectedStatus }}
                        </span>
                    </div>

                    <form method="POST" action="{{ route('absen.kanca.status.save') }}" id="statusForm">
                        @csrf
                        <input type="hidden" name="date" id="save_date" value="{{ $activeDate }}">
                        <input type="hidden" name="division" id="save_division" value="{{ $activeDivision }}">
                        <input type="hidden" name="search" id="save_search" value="{{ $search }}">
                        <input type="hidden" name="changes_payload" id="changes_payload" value="">
                        <input type="hidden" name="kanca_id" id="kanca_id" value="{{ $selectedId }}">

                        <div class="radio-list" id="statusRadioList">
                            @foreach ($statuses as $status)
                                <label class="radio-item">
                                    <input type="radio" name="status" value="{{ $status }}"
                                        @checked($selectedStatus === $status)>
                                    <span>{{ $status }}</span>
                                </label>
                            @endforeach
                        </div>

                        <label class="mini-label" for="notes">Catatan</label>
                        <textarea name="notes" id="notes" rows="4" placeholder="Tambahkan catatan bila perlu">{{ $selectedNotes }}</textarea>

                        <button type="submit" class="btn-save" @disabled(!$selectedId)>Simpan Status</button>
                        <div class="pending-note" id="pendingNote">Belum ada perubahan.</div>
                    </form>
                </section>

                <section class="glass-card side-card">
                    <div class="side-title">Rekap Realtime</div>
                    <div class="rekap-body">
                        <div class="row">
                            <div class="col-12">
                                <span class="p-2">Masuk :</span><strong
                                    id="sumMasuk">{{ $summary['Masuk'] ?? 0 }}</strong>
                                <span class="p-2">Telat :</span><strong
                                    id="sumTelat">{{ $summary['Telat'] ?? 0 }}</strong>
                                <span class="p-2">Sakit :</span><strong
                                    id="sumSakit">{{ $summary['Sakit'] ?? 0 }}</strong>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-12">
                                <span class="p-2">Absen :</span><strong
                                    id="sumMasuk">{{ $summary['Absen'] ?? 0 }}</strong>
                                <span class="p-2">Izin :</span><strong
                                    id="sumTelat">{{ $summary['Izin'] ?? 0 }}</strong>
                                <span class="p-2">Cuti :</span><strong
                                    id="sumSakit">{{ $summary['Cuti'] ?? 0 }}</strong>

                            </div>

                        </div>

                    </div>
                </section>

                <div class="kanca-copyright">&copy; itg_swj342_rpg0426_v3</div>
            </aside>
        </div>
    </div>
@endsection

@push('styles')
    <style>
        .kanca-page {
            max-width: min(1400px, 100%) !important;
            padding: 1rem !important;
        }

        .kanca-page .glass-card {
            margin-bottom: 0;
        }

        .kanca-header {
            margin-bottom: 1rem;
        }

        .header-pills {
            margin-top: .3rem;
            display: flex;
            flex-wrap: wrap;
            gap: .5rem;
        }

        .info-pill {
            display: inline-flex;
            align-items: center;
            gap: .42rem;
            border-radius: 999px;
            border: 1px solid rgba(255, 255, 255, .25);
            background: rgba(255, 255, 255, .12);
            color: #fff;
            font-size: .74rem;
            font-weight: 600;
            padding: .35rem .72rem;
        }

        .toolbar-card {
            margin-bottom: 1rem;
            padding: 1rem;
        }

        .toolbar-form {
            display: grid;
            gap: .7rem;
            grid-template-columns: 190px 110px 1.25fr 1.5fr;
            align-items: end;
        }

        .control-group {
            display: flex;
            flex-direction: column;
            gap: .35rem;
        }

        .mini-label {
            color: rgba(255, 255, 255, .62);
            font-size: .72rem;
            letter-spacing: .04em;
            text-transform: uppercase;
            font-weight: 600;
        }

        .ctl {
            width: 100%;
            border-radius: 11px;
            border: 1px solid rgba(255, 255, 255, .2);
            background: rgba(255, 255, 255, .09);
            color: rgba(255, 255, 255, .9);
            min-height: 41px;
            padding: .5rem .72rem;
            font-size: .85rem;
            outline: none;
            transition: border-color .2s, box-shadow .2s, background .2s;
        }

        .ctl:focus {
            border-color: rgba(99, 102, 241, .75);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, .2);
            background: rgba(255, 255, 255, .13);
        }

        .ctl option {
            color: #111;
        }

        .control-nav .nav-wrap {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: .42rem;
        }

        .ctl-nav {
            text-align: center;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-standard {
            min-height: 41px;
            border-radius: 11px;
            border: 1px solid rgba(99, 102, 241, .55);
            background: linear-gradient(135deg, rgba(99, 102, 241, .72), rgba(168, 85, 247, .62));
            color: #fff;
            font-size: .83rem;
            font-weight: 700;
            letter-spacing: .03em;
            transition: transform .2s, box-shadow .2s;
        }

        .btn-standard:hover {
            transform: translateY(-1px);
            box-shadow: 0 10px 20px rgba(99, 102, 241, .3);
        }

        .search-wrap {
            display: grid;
            grid-template-columns: minmax(0, 1fr) auto;
            gap: .5rem;
            align-items: center;
        }

        .btn-export {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .38rem;
            text-decoration: none;
            white-space: nowrap;
            padding: 0 .95rem;
            border-color: rgba(16, 185, 129, .6);
            background: linear-gradient(135deg, rgba(16, 185, 129, .88), rgba(6, 182, 212, .82));
        }

        .btn-export:hover {
            box-shadow: 0 10px 20px rgba(16, 185, 129, .28);
        }

        .kanca-grid {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 320px;
            gap: 1rem;
        }

        .table-card {
            overflow: hidden;
        }

        .table-headline {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: .85rem 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, .12);
            background: rgba(255, 255, 255, .04);
            color: #fff;
            font-size: .83rem;
            font-weight: 600;
        }

        .table-headline .left {
            display: inline-flex;
            align-items: center;
            gap: .45rem;
        }

        .table-headline .right {
            font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
            opacity: .8;
        }

        .table-scroll {
            max-height: calc(100vh - 250px);
            overflow: auto;
        }

        .table-scroll::-webkit-scrollbar {
            width: 9px;
            height: 9px;
        }

        .table-scroll::-webkit-scrollbar-thumb {
            background: rgba(165, 180, 252, .35);
            border-radius: 999px;
        }

        .kanca-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        .kanca-table thead th {
            position: sticky;
            top: 0;
            z-index: 2;
            background: rgba(18, 20, 60, .98);
            color: rgba(255, 255, 255, .68);
            font-size: .7rem;
            letter-spacing: .06em;
            text-transform: uppercase;
            padding: .72rem .75rem;
            border-bottom: 1px solid rgba(255, 255, 255, .12);
        }

        .kanca-table tbody td {
            color: rgba(255, 255, 255, .9);
            font-size: .82rem;
            padding: .66rem .75rem;
            border-bottom: 1px solid rgba(255, 255, 255, .08);
            white-space: nowrap;
        }

        .employee-row {
            cursor: pointer;
            transition: background .15s ease, transform .15s ease;
        }

        .employee-row:nth-child(even) {
            background: rgba(255, 255, 255, .02);
        }

        .employee-row:hover {
            background: rgba(99, 102, 241, .2);
        }

        .employee-row.selected {
            background: linear-gradient(90deg, rgba(99, 102, 241, .28), rgba(168, 85, 247, .2));
            box-shadow: inset 3px 0 0 rgba(52, 211, 153, .9);
        }

        .employee-row.pending-local {
            box-shadow: inset 3px 0 0 rgba(245, 158, 11, .95);
        }

        .status-tag {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 66px;
            padding: .22rem .58rem;
            border-radius: 999px;
            font-size: .72rem;
            font-weight: 700;
            border: 1px solid transparent;
        }

        .status-masuk {
            background: rgba(16, 185, 129, .17);
            border-color: rgba(16, 185, 129, .35);
            color: #6ee7b7;
        }

        .status-telat {
            background: rgba(245, 158, 11, .2);
            border-color: rgba(245, 158, 11, .45);
            color: #fcd34d;
        }

        .status-sakit {
            background: rgba(59, 130, 246, .2);
            border-color: rgba(59, 130, 246, .42);
            color: #93c5fd;
        }

        .status-absen {
            background: rgba(239, 68, 68, .22);
            border-color: rgba(239, 68, 68, .42);
            color: #fca5a5;
        }

        .status-izin {
            background: rgba(99, 102, 241, .2);
            border-color: rgba(129, 140, 248, .42);
            color: #c7d2fe;
        }

        .status-cuti {
            background: rgba(168, 85, 247, .2);
            border-color: rgba(196, 181, 253, .42);
            color: #ddd6fe;
        }

        .kanca-side {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .side-card {
            padding: 1rem;
        }

        .side-title {
            color: #fff;
            font-size: .94rem;
            font-weight: 700;
            margin-bottom: .75rem;
        }

        .selected-label {
            border: 1px solid rgba(255, 255, 255, .2);
            background: rgba(255, 255, 255, .09);
            border-radius: 12px;
            color: rgba(255, 255, 255, .95);
            padding: .62rem .7rem;
            font-size: .82rem;
            margin-bottom: .7rem;
        }

        .current-status-wrap {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: .7rem;
            gap: .5rem;
        }

        .radio-list {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: .45rem;
            margin-bottom: .8rem;
        }

        .radio-item {
            border: 1px solid rgba(255, 255, 255, .14);
            background: rgba(255, 255, 255, .05);
            border-radius: 10px;
            padding: .45rem .55rem;
            display: flex;
            align-items: center;
            gap: .42rem;
            color: rgba(255, 255, 255, .9);
            font-size: .78rem;
            cursor: pointer;
        }

        .radio-item input {
            accent-color: #34d399;
        }

        textarea {
            width: 100%;
            border: 1px solid rgba(255, 255, 255, .18);
            background: rgba(255, 255, 255, .08);
            color: rgba(255, 255, 255, .92);
            border-radius: 12px;
            padding: .58rem .7rem;
            font-size: .82rem;
            resize: vertical;
            min-height: 86px;
            margin-top: .35rem;
            margin-bottom: .8rem;
            outline: none;
        }

        textarea:focus {
            border-color: rgba(99, 102, 241, .75);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, .2);
        }

        .btn-save {
            width: 100%;
            min-height: 42px;
            border-radius: 12px;
            border: none;
            background: linear-gradient(135deg, rgba(16, 185, 129, .9), rgba(5, 150, 105, .85));
            color: #fff;
            font-size: .83rem;
            font-weight: 700;
            letter-spacing: .02em;
            transition: transform .2s, box-shadow .2s;
        }

        .btn-save:hover {
            transform: translateY(-1px);
            box-shadow: 0 10px 22px rgba(16, 185, 129, .35);
        }

        .btn-save:disabled {
            opacity: .5;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .pending-note {
            margin-top: .55rem;
            color: rgba(255, 255, 255, .65);
            font-size: .72rem;
            text-align: center;
        }

        .rekap-body {
            display: grid;
            gap: .45rem;
        }

        .rekap-body div {
            border: 1px solid rgba(255, 255, 255, .14);
            background: rgba(255, 255, 255, .05);
            border-radius: 10px;
            padding: .52rem .65rem;
            color: rgba(255, 255, 255, .88);
            font-size: .8rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .rekap-body strong {
            font-size: .9rem;
            color: #fff;
        }

        .kanca-copyright {
            margin-top: .1rem;
            text-align: center;
            font-size: .9rem;
            color: rgba(255, 255, 255, .62);
            letter-spacing: .03em;
        }

        .empty-state {
            text-align: center;
            padding: 1rem !important;
            color: rgba(255, 255, 255, .65) !important;
        }

        @media (min-width: 1081px) {
            body.kanca-fit-screen {
                padding-bottom: 0 !important;
                overflow: hidden;
            }

            .kanca-page {
                height: 100dvh;
                max-height: 100dvh;
                display: flex;
                flex-direction: column;
                overflow: hidden;
                padding-top: .75rem !important;
                padding-bottom: .75rem !important;
            }

            .kanca-header,
            .toolbar-card {
                flex-shrink: 0;
                margin-bottom: .75rem;
            }

            .kanca-grid {
                flex: 1;
                min-height: 0;
                grid-template-rows: minmax(0, 1fr);
            }

            .table-card {
                display: flex;
                flex-direction: column;
                min-height: 0;
                height: 100%;
            }

            .table-headline {
                flex-shrink: 0;
            }

            .table-scroll {
                flex: 1;
                min-height: 0;
                height: 100%;
                max-height: 100%;
                overflow-y: auto;
                overflow-x: auto;
            }

            .kanca-side {
                min-height: 0;
                overflow: auto;
                padding-right: .15rem;
            }

            .kanca-side::-webkit-scrollbar {
                width: 8px;
            }

            .kanca-side::-webkit-scrollbar-thumb {
                background: rgba(165, 180, 252, .35);
                border-radius: 999px;
            }
        }

        @media (max-width: 1240px) {
            .toolbar-form {
                grid-template-columns: 1fr 110px 1fr;
            }

            .control-search {
                grid-column: 1 / -1;
            }
        }

        @media (max-width: 1080px) {
            .kanca-grid {
                grid-template-columns: 1fr;
            }

            body.kanca-fit-screen {
                overflow: auto;
            }

            .table-scroll {
                max-height: 58vh;
            }
        }

        @media (max-width: 860px) {
            .kanca-page {
                padding: .75rem !important;
            }

            .toolbar-form {
                grid-template-columns: 1fr;
            }

            .control-search {
                grid-column: auto;
            }

            .search-wrap {
                grid-template-columns: 1fr;
            }

            .radio-list {
                grid-template-columns: 1fr;
            }
        }
    </style>
@endpush

@push('scripts')
    <script>
        (function() {
            document.body.classList.add('kanca-fit-screen');

            const filterForm = document.getElementById('filterForm');
            const statusForm = document.getElementById('statusForm');
            const dateInput = document.getElementById('date');
            const divisionInput = document.getElementById('division');
            const searchInput = document.getElementById('search');
            const exportExcelBtn = document.getElementById('exportExcelBtn');
            const selectedFilter = document.getElementById('selected_filter');
            const divisionPrevBtn = document.getElementById('divisionPrevBtn');
            const divisionNextBtn = document.getElementById('divisionNextBtn');

            const tableBody = document.querySelector('#attendanceTable tbody');
            const tableScroll = document.querySelector('.table-scroll');
            const selectedPegawai = document.getElementById('selectedPegawai');
            const selectedStatusBadge = document.getElementById('selectedStatusBadge');
            const kancaInput = document.getElementById('kanca_id');
            const notesInput = document.getElementById('notes');
            const saveButton = document.querySelector('.btn-save');
            const pendingNote = document.getElementById('pendingNote');
            const saveDateInput = document.getElementById('save_date');
            const saveDivisionInput = document.getElementById('save_division');
            const saveSearchInput = document.getElementById('save_search');
            const changesPayloadInput = document.getElementById('changes_payload');

            const totalEmployeesText = document.getElementById('totalEmployeesText');
            const scopeText = document.getElementById('scopeText');
            const activeDateText = document.getElementById('activeDateText');

            const summaryEls = {
                Masuk: document.getElementById('sumMasuk'),
                Telat: document.getElementById('sumTelat'),
                Sakit: document.getElementById('sumSakit'),
                Absen: document.getElementById('sumAbsen'),
                Izin: document.getElementById('sumIzin'),
                Cuti: document.getElementById('sumCuti'),
            };

            const knownStatuses = ['Masuk', 'Telat', 'Sakit', 'Absen', 'Izin', 'Cuti'];
            const pendingChanges = new Map();
            let debounceTimer = null;
            let requestSeq = 0;
            const exportBaseUrl = @json(route('absen.kanca.export'));

            function escapeHtml(text) {
                return String(text ?? '')
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#039;');
            }

            function normalizeStatus(statusValue) {
                const text = String(statusValue || '').trim().toLowerCase();
                const found = knownStatuses.find((s) => s.toLowerCase() === text);
                return found || 'Masuk';
            }

            function setStatusRadio(statusValue) {
                const radios = document.querySelectorAll('input[name="status"]');
                radios.forEach((radio) => {
                    radio.checked = radio.value === statusValue;
                });
            }

            function setStatusBadge(statusValue) {
                if (!selectedStatusBadge) {
                    return;
                }
                const status = normalizeStatus(statusValue);
                selectedStatusBadge.className = 'status-tag status-' + status.toLowerCase();
                selectedStatusBadge.textContent = status;
            }

            function updatePendingUI() {
                const count = pendingChanges.size;
                changesPayloadInput.value = count > 0 ?
                    JSON.stringify(Array.from(pendingChanges.values())) :
                    '';

                if (pendingNote) {
                    pendingNote.textContent = count > 0 ?
                        `${count} perubahan belum disimpan.` :
                        'Belum ada perubahan.';
                }

                if (saveButton) {
                    saveButton.disabled = count === 0;
                }
            }

            function fitTableScrollHeight() {
                if (!tableScroll) {
                    return;
                }

                if (window.innerWidth <= 1080) {
                    tableScroll.style.height = '';
                    tableScroll.style.maxHeight = '';
                    return;
                }

                const rect = tableScroll.getBoundingClientRect();
                const bottomGap = 14; // ruang bawah agar tidak nempel viewport
                const available = Math.floor(window.innerHeight - rect.top - bottomGap);

                if (available > 220) {
                    tableScroll.style.height = `${available}px`;
                    tableScroll.style.maxHeight = `${available}px`;
                }
            }

            function syncSaveFilters() {
                saveDateInput.value = dateInput.value;
                saveDivisionInput.value = divisionInput.value;
                saveSearchInput.value = searchInput.value;
                updateExportHref();
            }

            function updateExportHref() {
                if (!exportExcelBtn) {
                    return;
                }

                const params = new URLSearchParams({
                    date: dateInput.value || '',
                    division: divisionInput.value || '',
                    search: searchInput.value || '',
                });
                exportExcelBtn.href = `${exportBaseUrl}?${params.toString()}`;
            }

            function setSelectedRowUI(id) {
                const rows = tableBody.querySelectorAll('.employee-row');
                rows.forEach((row) => {
                    row.classList.toggle('selected', String(row.dataset.kancaId) === String(id));
                });
            }

            function setSelectedData(data) {
                const id = data?.id ? String(data.id) : '';
                const name = data?.name || '(Belum memilih pegawai)';
                const status = normalizeStatus(data?.status || 'Masuk');
                const notes = data?.notes || '';

                kancaInput.value = id;
                selectedFilter.value = id;
                selectedPegawai.textContent = name;
                notesInput.value = notes;

                setStatusRadio(status);
                setStatusBadge(status);
                setSelectedRowUI(id);
            }

            function setRowStatusPreview(row, statusValue, markPending = true) {
                if (!row) {
                    return;
                }

                const status = normalizeStatus(statusValue);
                row.dataset.status = status;
                row.classList.toggle('pending-local', markPending);

                const statusCell = row.children[3];
                const indicatorCell = row.children[4];

                if (statusCell) {
                    statusCell.innerHTML =
                        `<span class="status-tag status-${escapeHtml(status.toLowerCase())}">${escapeHtml(status)}</span>`;
                }

                if (indicatorCell) {
                    indicatorCell.textContent = status.charAt(0).toUpperCase();
                }
            }

            function syncPendingForRow(row) {
                if (!row) {
                    return;
                }

                const id = String(row.dataset.kancaId || '');
                if (!id) {
                    return;
                }

                const currentStatus = normalizeStatus(row.dataset.status || 'Masuk');
                const currentNotes = String(row.dataset.notes || '');
                const originalStatus = normalizeStatus(row.dataset.originalStatus || 'Masuk');
                const originalNotes = String(row.dataset.originalNotes || '');

                if (currentStatus === originalStatus && currentNotes === originalNotes) {
                    pendingChanges.delete(id);
                    row.classList.remove('pending-local');
                } else {
                    pendingChanges.set(id, {
                        kanca_id: Number(id),
                        status: currentStatus,
                        notes: currentNotes,
                    });
                    row.classList.add('pending-local');
                }

                updatePendingUI();
            }

            function recomputeSummaryFromTable() {
                const counts = {
                    Masuk: 0,
                    Telat: 0,
                    Sakit: 0,
                    Absen: 0,
                    Izin: 0,
                    Cuti: 0,
                };

                tableBody.querySelectorAll('.employee-row').forEach((row) => {
                    const status = normalizeStatus(row.dataset.status || 'Masuk');
                    counts[status] = (counts[status] || 0) + 1;
                });

                Object.keys(summaryEls).forEach((key) => {
                    if (summaryEls[key]) {
                        summaryEls[key].textContent = String(counts[key] ?? 0);
                    }
                });
            }

            function findRowById(id) {
                return Array.from(tableBody.querySelectorAll('.employee-row'))
                    .find((row) => String(row.dataset.kancaId) === String(id)) || null;
            }

            function applyPendingToRenderedRows() {
                tableBody.querySelectorAll('.employee-row').forEach((row) => {
                    const pending = pendingChanges.get(String(row.dataset.kancaId || ''));
                    if (!pending) {
                        return;
                    }

                    row.dataset.notes = String(pending.notes || '');
                    setRowStatusPreview(row, pending.status, true);
                });
            }

            function renderRows(rows, selectedId) {
                if (!Array.isArray(rows) || rows.length === 0) {
                    tableBody.innerHTML =
                        '<tr><td colspan="5" class="empty-state">Tidak ada data sesuai filter.</td></tr>';
                    return;
                }

                tableBody.innerHTML = rows.map((row) => {
                    const id = String(row.id ?? '');
                    const isSelected = String(selectedId) === id;
                    const status = normalizeStatus(row.status ?? 'Masuk');
                    const notes = String(row.notes ?? '');

                    return `
                        <tr class="employee-row ${isSelected ? 'selected' : ''}"
                            data-kanca-id="${escapeHtml(id)}"
                            data-name="${escapeHtml(row.name ?? '')}"
                            data-status="${escapeHtml(status)}"
                            data-notes="${escapeHtml(notes)}"
                            data-original-status="${escapeHtml(status)}"
                            data-original-notes="${escapeHtml(notes)}">
                            <td>${escapeHtml(row.division ?? '')}</td>
                            <td>${escapeHtml(row.jabatan ?? '')}</td>
                            <td>${escapeHtml(row.name ?? '')}</td>
                            <td><span class="status-tag status-${escapeHtml(status.toLowerCase())}">${escapeHtml(status)}</span></td>
                            <td>${escapeHtml(row.indicator ?? '')}</td>
                        </tr>
                    `;
                }).join('');
            }

            async function loadKancaData(resetSelected = false) {
                if (resetSelected) {
                    selectedFilter.value = '';
                }
                syncSaveFilters();

                const params = new URLSearchParams({
                    date: dateInput.value || '',
                    division: divisionInput.value || '',
                    search: searchInput.value || '',
                    selected: selectedFilter.value || '',
                    ajax: '1',
                });

                const reqId = ++requestSeq;

                try {
                    const resp = await fetch(`{{ route('Input-Index-Kanca') }}?${params.toString()}`, {
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                    });
                    if (!resp.ok) {
                        return;
                    }

                    const payload = await resp.json();
                    if (reqId !== requestSeq) {
                        return;
                    }

                    const rows = payload.rows || [];
                    const selectedId = selectedFilter.value || payload.selectedRow?.id || rows[0]?.id || '';

                    renderRows(rows, selectedId);
                    applyPendingToRenderedRows();

                    const selectedRow = findRowById(selectedId);
                    if (selectedRow) {
                        setSelectedData({
                            id: selectedRow.dataset.kancaId || '',
                            name: selectedRow.dataset.name || '',
                            status: selectedRow.dataset.status || 'Masuk',
                            notes: selectedRow.dataset.notes || '',
                        });
                    } else {
                        setSelectedData(null);
                    }

                    totalEmployeesText.textContent = String(payload.totalEmployees ?? 0);
                    scopeText.textContent = payload.activeDivision ? payload.activeDivision : 'Semua Divisi';
                    activeDateText.textContent = payload.activeDate || dateInput.value;

                    Object.keys(summaryEls).forEach((key) => {
                        if (summaryEls[key]) {
                            summaryEls[key].textContent = String((payload.summary || {})[key] ?? 0);
                        }
                    });

                    recomputeSummaryFromTable();
                    updatePendingUI();
                    fitTableScrollHeight();
                } catch (err) {
                    console.error(err);
                }
            }

            function debounceLoad() {
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    loadKancaData(true);
                }, 300);
            }

            function stepDivision(step) {
                const options = Array.from(divisionInput.options);
                if (options.length < 2) {
                    return;
                }
                const currentIndex = Math.max(0, divisionInput.selectedIndex);
                const nextIndex = (currentIndex + step + options.length) % options.length;
                divisionInput.selectedIndex = nextIndex;
                loadKancaData(true);
            }

            document.querySelectorAll('input[name="status"]').forEach((radio) => {
                radio.addEventListener('change', function() {
                    if (!this.checked) {
                        return;
                    }

                    setStatusBadge(this.value);

                    const selectedRow = tableBody.querySelector('.employee-row.selected');
                    if (!selectedRow) {
                        return;
                    }

                    setRowStatusPreview(selectedRow, this.value, true);
                    syncPendingForRow(selectedRow);
                    recomputeSummaryFromTable();
                });
            });

            notesInput.addEventListener('input', () => {
                const selectedRow = tableBody.querySelector('.employee-row.selected');
                if (!selectedRow) {
                    return;
                }
                selectedRow.dataset.notes = notesInput.value || '';
                syncPendingForRow(selectedRow);
            });

            tableBody.addEventListener('click', (event) => {
                const row = event.target.closest('.employee-row');
                if (!row) {
                    return;
                }

                setSelectedData({
                    id: row.dataset.kancaId || '',
                    name: row.dataset.name || '',
                    status: row.dataset.status || 'Masuk',
                    notes: row.dataset.notes || '',
                });
            });

            filterForm.addEventListener('submit', (event) => {
                event.preventDefault();
                loadKancaData(false);
            });

            divisionInput.addEventListener('change', () => {
                updateExportHref();
                loadKancaData(true);
            });
            dateInput.addEventListener('change', () => {
                updateExportHref();
                loadKancaData(true);
            });
            searchInput.addEventListener('input', () => {
                updateExportHref();
                debounceLoad();
            });

            divisionPrevBtn.addEventListener('click', () => stepDivision(-1));
            divisionNextBtn.addEventListener('click', () => stepDivision(1));
            window.addEventListener('resize', fitTableScrollHeight);

            statusForm.addEventListener('submit', (event) => {
                syncSaveFilters();
                if (pendingChanges.size === 0) {
                    event.preventDefault();
                    return;
                }
                changesPayloadInput.value = JSON.stringify(Array.from(pendingChanges.values()));
            });

            syncSaveFilters();
            updatePendingUI();
            updateExportHref();
            fitTableScrollHeight();
        })();
    </script>

    @if (session('success'))
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: @json(session('success')),
                timer: 2200,
                timerProgressBar: true,
                showConfirmButton: false,
                background: '#1a1a4e',
                color: '#fff',
                iconColor: '#34d399'
            });
        </script>
    @endif

    @if ($errors->any())
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Data belum lengkap',
                html: @json($errors->all()).map(msg => `• ${msg}`).join('<br>'),
                confirmButtonText: 'Tutup',
                confirmButtonColor: '#6366f1',
                background: '#1a1a4e',
                color: '#fff'
            });
        </script>
    @endif
@endpush
